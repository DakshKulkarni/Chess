using UnityEngine;
public class ChessBoardPlacementHandler : MonoBehaviour
{
    [SerializeField] private GameObject[] _rowsArray;
    [SerializeField] private GameObject _highlightPrefab;
    [SerializeField] private GameObject _enemyHighlightPrefab; 
    [SerializeField] private GameObject[,] _chessBoard;
    internal static ChessBoardPlacementHandler Instance;
    private void Awake()
    {
        Instance = this;
        GenerateArray();
    }
    private void GenerateArray()
    {
        _chessBoard = new GameObject[8, 8];
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                _chessBoard[i, j] = _rowsArray[i].transform.GetChild(j).gameObject;
            }
        }
    }
    internal GameObject GetTile(int row, int column)
    {
        try
        {
            return _chessBoard[row, column];
        }
        catch (System.Exception)
        {
            Debug.LogError("Invalid row or column.");
            return null;
        }
    }
    internal void Highlight(int row, int col, Color? color = null)
    {
        var tile = GetTile(row, col).transform;
        if (tile == null)
        {
            Debug.LogError("Invalid row or column.");
            return;
        }
        GameObject highlightPrefab = color.HasValue && color == Color.red ? _enemyHighlightPrefab : _highlightPrefab;

        Instantiate(highlightPrefab, tile.position, Quaternion.identity);
    }
    internal void ClearHighlights()
    {
        foreach (GameObject tile in _chessBoard)
        {
            foreach (Transform child in tile.transform)
            {
                Destroy(child.gameObject);
            }
        }
    }
}
