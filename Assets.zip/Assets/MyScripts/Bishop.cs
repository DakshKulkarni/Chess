using Chess.Scripts.Core;
using UnityEngine;
public class Bishop : MonoBehaviour
{
    private void OnMouseDown()
    {
        HighlightLegalMoves();
    }
    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler bishopPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = bishopPlacement.row;
        int currentColumn = bishopPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        HighlightDiagonalMoves(currentRow, currentColumn, 1, 1); 
        HighlightDiagonalMoves(currentRow, currentColumn, 1, -1); 
        HighlightDiagonalMoves(currentRow, currentColumn, -1, 1); 
        HighlightDiagonalMoves(currentRow, currentColumn, -1, -1); 
    }
 private void HighlightDiagonalMoves(int row, int column, int rowDirection, int columnDirection)
{
    ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;
    while (true)
    {
        row += rowDirection;
        column += columnDirection;
        if (row < 0 || row >= 8 || column < 0 || column >= 8)
            break;
        if (IsTileOccupied(row, column))
            break; 
        if (IsTileOccupiedByEnemy(row, column))
        {
            chessBoard.Highlight(row, column, Color.red);
        }
        else
        {
            chessBoard.Highlight(row, column);
        }
    }
}
    private bool IsTileOccupied(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("ChessPiece");
    }
    private bool IsTileOccupiedByEnemy(int row, int column)
{
    RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
    return hit.collider != null && hit.collider.CompareTag("EnemyPiece");
}
}
