using Chess.Scripts.Core;
using UnityEngine;
public class King : MonoBehaviour
{
    private void OnMouseDown()
    {
        HighlightLegalMoves();
    }
    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler kingPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = kingPlacement.row;
        int currentColumn = kingPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        for (int row = currentRow - 1; row <= currentRow + 1; row++)
        {
            for (int column = currentColumn - 1; column <= currentColumn + 1; column++)
            {
                HighlightSingleMove(row, column);
            }
        }
    }
    private void HighlightSingleMove(int row, int column)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;

        if (IsTileValid(row, column))
        {
            if (IsTileOccupiedByEnemy(row, column))
            {
                chessBoard.Highlight(row, column, Color.red);
            }
            else
            {
                chessBoard.Highlight(row, column);
            }
        }
    }
    private bool IsTileValid(int row, int column)
    {
        return row >= 0 && row < 8 && column >= 0 && column < 8;
    }
    private bool IsTileOccupiedByEnemy(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("EnemyPiece");
    }
}
