using Chess.Scripts.Core;
using UnityEngine;
using System.Collections;

public class Knight : MonoBehaviour
{
   private void OnMouseDown()
    {
        HighlightLegalMoves();
    }

    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler knightPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = knightPlacement.row;
        int currentColumn = knightPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        int[] rowOffsets = { 2, 2, 1, 1, -1, -1, -2, -2 };
        int[] columnOffsets = { 1, -1, 2, -2, 2, -2, 1, -1 };
        for (int i = 0; i < rowOffsets.Length; i++)
        {
            int newRow = currentRow + rowOffsets[i];
            int newColumn = currentColumn + columnOffsets[i];

            if (IsMoveValid(newRow, newColumn))
            {
                if (!IsTileOccupied(newRow, newColumn))
                {
                    HighlightSingleMove(newRow, newColumn);
                }
                else if (IsTileOccupiedByEnemy(newRow, newColumn))
                {
                    HighlightSingleMove(newRow, newColumn, Color.red);
                }
            }
        }
    }
    private bool IsMoveValid(int row, int column)
    {
        return row >= 0 && row < 8 && column >= 0 && column < 8;
    }    private void HighlightSingleMove(int row, int column, Color color)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;

        chessBoard.Highlight(row, column, color);
    }
    private void HighlightSingleMove(int row, int column)
    {
        HighlightSingleMove(row, column, Color.green);
    }
    private bool IsTileOccupied(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("ChessPiece");
    }
    private bool IsTileOccupiedByEnemy(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("EnemyPiece");
    }
}