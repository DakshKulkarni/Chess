using Chess.Scripts.Core;
using UnityEngine;
public class Pawn : MonoBehaviour
{
    private void OnMouseDown()
    {
        HighlightLegalMoves();
    }
    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler pawnPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = pawnPlacement.row;
        int currentColumn = pawnPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        HighlightMoves(currentRow, currentColumn);
    }
    private void HighlightMoves(int row, int column)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;
        int direction = GetComponent<SpriteRenderer>().color == Color.white ? 1 : -1;
        HighlightSingleMove(row + direction, column);
        if ((direction == 1 && row == 1) || (direction == -1 && row == 6))
        {
            HighlightSingleMove(row + 2 * direction, column);
        }
        HighlightCaptureMove(row + direction, column - 1);
        HighlightCaptureMove(row + direction, column + 1);
    }
    private void HighlightSingleMove(int row, int column)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;

        if (IsTileValidAndEmpty(row, column))
        {
            chessBoard.Highlight(row, column);
        }
    }
    private void HighlightCaptureMove(int row, int column)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;

        if (IsTileValid(row, column) && IsTileOccupiedByEnemy(row, column))
        {
            chessBoard.Highlight(row, column, Color.red);
        }
    }
    private bool IsTileValidAndEmpty(int row, int column)
    {
        return IsTileValid(row, column) && !IsTileOccupied(row, column);
    }
    private bool IsTileValid(int row, int column)
    {
        return row >= 0 && row < 8 && column >= 0 && column < 8;
    }
    private bool IsTileOccupied(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("ChessPiece");
    }
    private bool IsTileOccupiedByEnemy(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("EnemyPiece");
    }
}