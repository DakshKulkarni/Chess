using Chess.Scripts.Core;
using UnityEngine;
public class Queen : MonoBehaviour
{
    private void OnMouseDown()
    {
        HighlightLegalMoves();
    }
    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler queenPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = queenPlacement.row;
        int currentColumn = queenPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        HighlightMovesInDirection(currentRow, currentColumn, 1, 0); 
        HighlightMovesInDirection(currentRow, currentColumn, -1, 0); 
        HighlightMovesInDirection(currentRow, currentColumn, 0, 1); 
        HighlightMovesInDirection(currentRow, currentColumn, 0, -1); 
        HighlightMovesInDirection(currentRow, currentColumn, 1, 1); 
        HighlightMovesInDirection(currentRow, currentColumn, 1, -1);
        HighlightMovesInDirection(currentRow, currentColumn, -1, 1); 
        HighlightMovesInDirection(currentRow, currentColumn, -1, -1); 
    }
    private void HighlightMovesInDirection(int row, int column, int rowDirection, int columnDirection)
{
    ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;
    while (true)
    {
        row += rowDirection;
        column += columnDirection;
        if (row < 0 || row >= 8 || column < 0 || column >= 8)
            break;
        if (IsTileOccupied(row, column))
        {
            break;
        }
        if (IsTileOccupiedByEnemy(row, column))
        {
            chessBoard.Highlight(row, column, Color.red);
        }
        else
        {
            chessBoard.Highlight(row, column);
        }
    }
}
    private bool IsTileOccupied(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        if (hit.collider != null && hit.collider.CompareTag("ChessPiece"))
        {
            return true;
        }

        return false;
    }
    private bool IsTileOccupiedByEnemy(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        if (hit.collider != null && hit.collider.CompareTag("EnemyPiece"))
        {
            return true;
        }
        return false;
    }
}