using Chess.Scripts.Core;
using UnityEngine;
public class Rook : MonoBehaviour
{
     private bool isHighlighted = false;

    private void OnMouseDown()
    {
        if (isHighlighted)
        {
            ChessBoardPlacementHandler.Instance.ClearHighlights();
            isHighlighted = false;
        }
        else
        {
            HighlightLegalMoves();
            isHighlighted = true;
        }
    }
    private void HighlightLegalMoves()
    {
        ChessPlayerPlacementHandler rookPlacement = GetComponent<ChessPlayerPlacementHandler>();
        int currentRow = rookPlacement.row;
        int currentColumn = rookPlacement.column;
        ChessBoardPlacementHandler.Instance.ClearHighlights();
        HighlightStraightMoves(currentRow, currentColumn, 1, 0); 
        HighlightStraightMoves(currentRow, currentColumn, -1, 0); 
        HighlightStraightMoves(currentRow, currentColumn, 0, 1); 
        HighlightStraightMoves(currentRow, currentColumn, 0, -1); 
    }
    private void HighlightStraightMoves(int row, int column, int rowDirection, int columnDirection)
    {
        ChessBoardPlacementHandler chessBoard = ChessBoardPlacementHandler.Instance;
        while (true)
        {
            row += rowDirection;
            column += columnDirection;
            if (row < 0 || row >= 8 || column < 0 || column >= 8)
                break;
            if (IsTileOccupied(row, column))
                break; 
            if (IsTileOccupiedByEnemy(row, column))
            {
                chessBoard.Highlight(row, column, Color.red);
            }
            else
            {
                chessBoard.Highlight(row, column);
            }
        }
    }
    private bool IsTileOccupied(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("ChessPiece");
    }    private bool IsTileOccupiedByEnemy(int row, int column)
    {
        RaycastHit2D hit = Physics2D.Raycast(ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position, Vector2.zero);
        return hit.collider != null && hit.collider.CompareTag("EnemyPiece");
    }
}
